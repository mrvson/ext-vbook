// _probe_cover.js — kiểm tra chuỗi redirect cover trên thiết bị
function execute(url) {
    var out = [];
    var COVER = "https://javsub.blog/resize/800/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg";

    var r1 = fetch(COVER);
    out.push({ step: "resize", status: r1.status, loc: (r1.headers["location"] || r1.headers["Location"] || "") + "", ct: (r1.headers["content-type"] || "") + "" });

    var loc = (r1.headers["location"] || "") + "";
    if (!loc && typeof r1.url === "string") {
        // thử lấy từ request
    }

    if (loc) {
        if (loc.indexOf("//") === 0) loc = "https:" + loc;
        if (loc.indexOf("http") !== 0) loc = "https://javsub.blog" + loc;
        var r2 = fetch(loc, { headers: { "Referer": "https://javsub.blog/" } });
        var b64 = "";
        try { b64 = (r2.base64 ? r2.base64() : "") + ""; } catch (e) {}
        out.push({
            step: "gate",
            url: loc.substring(0, 90),
            status: r2.status,
            ct: (r2.headers["content-type"] || "") + "",
            b64head: b64.substring(0, 20)
        });
    }
    return Response.success(out);
}
