// _probe_cover2.js — quét nhiều biến thể URL ảnh
function execute(url) {
    var out = [];
    var paths = [
        "/resize/800/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg",
        "/resize/300/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg",
        "/upload/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg",
        "/images/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg",
        "/media/2026/06/26/bae3b69ba71828430f67215cf0830bdec046038d9cf60a7a95c0ae88f55d349d.jpg",
        "https://mio9ecge.name/videos/691d1ff890517a2c25046f34/posters/3.jpg"
    ];
    for (var i = 0; i < paths.length; i++) {
        try {
            var u = paths[i];
            if (u.indexOf("http") !== 0) u = "https://javsub.blog" + u;
            var r = fetch(u, { headers: { "Referer": "https://javsub.blog/" } });
            var b64 = "";
            try { if (r.ok) b64 = (r.base64 ? r.base64() : "") + ""; } catch (e) {}
            out.push({
                path: u.replace("https://javsub.blog", "").substring(0, 40),
                status: r.status,
                ct: (r.headers["content-type"] || "") + "",
                png: b64.substring(0, 12)
            });
        } catch (e2) {
            out.push({ path: paths[i].substring(0, 40), error: e2.message });
        }
    }
    return Response.success(out);
}
